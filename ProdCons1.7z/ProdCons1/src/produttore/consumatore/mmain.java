package produttore.consumatore;
import java.util.Scanner;
public class mmain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int cap=0; 
		
		
		Scanner input =new Scanner(System.in);
		System.out.println("Inserisci capienza buffer:");
		cap=input.nextInt();
	        bafferr buffer = new bafferr(5);  

	        Thread produttore = new Thread(new produttore(buffer));
	        Thread consumatore = new Thread(new consumatore(buffer));

	        produttore.start();
	        consumatore.start();
	   
	}

}
