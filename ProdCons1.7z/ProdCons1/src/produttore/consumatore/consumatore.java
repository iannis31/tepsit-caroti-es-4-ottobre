package produttore.consumatore;

public class consumatore implements Runnable {
	private bafferr buffer;

    public consumatore(bafferr buffer) {
        this.buffer = buffer;
    }

    @Override
    public void run() {
        try {
            while (true) {
                buffer.consume();
                Thread.sleep(150);  // Simula il tempo per consumare un elemento
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}

