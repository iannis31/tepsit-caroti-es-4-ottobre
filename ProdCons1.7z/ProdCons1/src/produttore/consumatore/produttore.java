package produttore.consumatore;

public class produttore implements Runnable  {
	private bafferr buffer;

    public produttore(bafferr buffer) {
        this.buffer = buffer;
    }

    @Override
    public void run() {
        int value = 0;
        try {
            while (true) {
                buffer.produce(value++);
                Thread.sleep(100);  // Simula il tempo per produrre un nuovo elemento
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}


