package produttore.consumatore;
import java.util.LinkedList;
import java.util.Queue;

public class bafferr {
	private Queue<Integer> queue = new LinkedList<>();
    private int capacity;

    public bafferr(int capacity) {
        this.capacity = capacity;
    }

// Produce permette al thread di aggiumgere un elemento al buffer
    public synchronized void produce(int value) throws InterruptedException {


// Controllo se il baffer è pieno, se si sospendo il produttore
        while (queue.size() == capacity) {
            wait();
        }

        
// Aggiungo l'elemento al buffer
        queue.add(value);
        System.out.println("Prodotto: " + value);

        
// Risveglio i consumatori visto lìaggiunta di un nuovo elemento 
        notifyAll();
    }

    
    
    
// permette a un thread consumatore di prelevare un elemento dal buffer
    public synchronized int consume() throws InterruptedException {
    	
    	
// Se il buffer è vuoto, attendi che ci sia un elemento
        while (queue.isEmpty()) {
            wait();
        }

        
// Rimuovi l'elemento dal buffer
        int value = queue.poll();
        System.out.println("Consumatore ha consumato: " + value);
        
        

// Risveglio i produttore ch c'è spazoo nel buffer
        notifyAll();
        return value;
    }
}

